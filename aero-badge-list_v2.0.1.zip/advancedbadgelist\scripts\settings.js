(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };

  // src/themeColors.js
  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }
  function round(value) {
    return Math.round(value * 10) / 10;
  }
  function hsl(h, s, l, a = 1) {
    const hue = (Math.round(h) % 360 + 360) % 360;
    const sat = round(clamp(s, 0, 100));
    const light = round(clamp(l, 0, 100));
    if (a >= 1) {
      return `hsl(${hue}, ${sat}%, ${light}%)`;
    }
    return `hsla(${hue}, ${sat}%, ${light}%, ${a})`;
  }
  function num(value, fallback) {
    const parsed = typeof value === "number" ? value : typeof value === "string" && value.trim() !== "" ? Number(value) : NaN;
    return Number.isFinite(parsed) ? parsed : fallback;
  }
  function normalizeTheme(stored) {
    const theme = stored && typeof stored === "object" ? stored : {};
    const preset = PRESETS[theme.preset] ? theme.preset : theme.preset === "custom" ? "custom" : "aero";
    const base = PRESETS[preset] || PRESETS.aero;
    return {
      preset,
      hue: num(theme.hue, base.hue),
      sat: clamp(num(theme.sat, base.sat), 0, 100)
    };
  }
  function lightSurface(h, s) {
    return {
      "--abl-gloss": `linear-gradient(to bottom, rgba(255, 255, 255, 0.92) 0%, rgba(255, 255, 255, 0.5) 44%, rgba(255, 255, 255, 0.06) 52%, rgba(255, 255, 255, 0.3) 100%)`,
      "--abl-wash": `linear-gradient(to bottom, ${hsl(h, s, 93, 0.55)} 0%, ${hsl(h, s, 80, 0.6)} 55%, ${hsl(h, s, 71, 0.85)} 100%)`,
      "--abl-panel-border": hsl(h, s * 0.9, 52, 0.5),
      "--abl-panel-border-top": "rgba(255, 255, 255, 0.95)",
      "--abl-panel-shadow": `inset 0 1px 0 rgba(255, 255, 255, 0.95), inset 0 -1px 0 ${hsl(h, s, 60, 0.35)}, 0 2px 6px ${hsl(h, s * 0.6, 35, 0.2)}`,
      "--abl-icon-tint": hsl(h, s, 60, 0.14),
      "--abl-icon-border": hsl(h, s, 50, 0.4),
      "--abl-ghost-hover": hsl(h, s, 60, 0.18)
    };
  }
  function darkSurface(h, s) {
    return {
      "--abl-gloss": "linear-gradient(to bottom, rgba(255, 255, 255, 0.14) 0%, rgba(255, 255, 255, 0.04) 10%, rgba(255, 255, 255, 0) 32%)",
      "--abl-wash": `linear-gradient(to bottom, ${hsl(h, s, 56, 0.14)}, rgba(6, 10, 16, 0) 60%)`,
      "--abl-panel-border": hsl(h, s, 79, 0.45),
      "--abl-panel-border-top": hsl(h, s, 89, 0.85),
      "--abl-panel-shadow": "inset 0 1px 0 rgba(255, 255, 255, 0.5), inset 0 -1px 0 rgba(0, 0, 0, 0.5), 0 2px 5px rgba(0, 0, 0, 0.45)",
      "--abl-icon-tint": hsl(h, s, 74, 0.08),
      "--abl-icon-border": hsl(h, s, 79, 0.25),
      "--abl-ghost-hover": hsl(h, s, 74, 0.12)
    };
  }
  function themeVars(stored, mode = "dark") {
    const { preset, hue, sat } = normalizeTheme(stored);
    const surfaceMode = SURFACES[mode] ? mode : "dark";
    const vars = {
      "--abl-color-surface": SURFACES[surfaceMode],
      "--abl-aero-border-bright": hsl(hue, sat, 89, 0.85),
      "--abl-aero-accent-dark": hsl(hue + 4, sat * 0.9, 18),
      "--abl-btn-top": hsl(hue, sat, 62),
      "--abl-btn-mid": hsl(hue, sat * 0.9, 36),
      "--abl-knob-mid": hsl(hue, sat * 0.3, 92),
      "--abl-knob-edge": hsl(hue, sat * 0.5, 84),
      ...surfaceMode === "light" ? lightSurface(hue, sat) : darkSurface(hue, sat)
    };
    if (preset === "mono") {
      Object.assign(vars, MONO_OVERRIDES);
    }
    return vars;
  }
  var PRESETS, MONO_OVERRIDES, SURFACES;
  var init_themeColors = __esm({
    "src/themeColors.js"() {
      PRESETS = {
        aero: { hue: 200, sat: 95 },
        mono: { hue: 0, sat: 0 }
      };
      MONO_OVERRIDES = {
        "--abl-toggle-off": "#3a3a3a",
        "--abl-toggle-on": "#cfcfcf",
        "--abl-rarity-valuable": "#ffffff",
        "--abl-rarity-legacy": "#9a9a9a",
        "--abl-rarity-nvl": "#4a4a4a",
        "--abl-rarity-valuable-glow": "rgba(255, 255, 255, 0.6)",
        "--abl-rarity-legacy-glow": "rgba(154, 154, 154, 0.5)",
        "--abl-rarity-nvl-glow": "rgba(74, 74, 74, 0.6)"
      };
      SURFACES = {
        light: "rgb(251, 252, 253)",
        dark: "rgb(13, 13, 16)",
        unknown: "rgba(20, 20, 20, 0.05)"
      };
    }
  });

  // src/settings.jsx
  var require_settings = __commonJS({
    "src/settings.jsx"() {
      init_themeColors();
      (async function() {
        function createElement(tag, props, ...children) {
          const el = document.createElement(tag);
          for (const [k, v] of Object.entries(props || {})) {
            if (k === "className") el.className = v;
            else if (k === "style") Object.assign(el.style, v);
            else if (k.startsWith("on")) el.addEventListener(k.slice(2).toLowerCase(), v);
            else if (k === "hidden") el.hidden = v;
            else el.setAttribute(k, v);
          }
          children.flat().forEach((c) => {
            if (c == null) return;
            el.append(c instanceof Node ? c : document.createTextNode(c));
          });
          return el;
        }
        const style = document.createElement("style");
        style.innerHTML = `
    .abl-toggle {
        width: 44px;
        height: 24px;
        border-radius: 0;
        background: linear-gradient(to bottom, rgba(255, 255, 255, 0.25) 0%, rgba(255, 255, 255, 0) 45%), #b0362f;
        border: 1px solid rgba(0, 0, 0, 0.4);
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.4);
        position: relative;
        cursor: pointer;
        transition: background 0.2s ease;
    }

    .abl-toggle.on {
        background: linear-gradient(to bottom, rgba(255, 255, 255, 0.3) 0%, rgba(255, 255, 255, 0) 45%), #2e9e46;
    }

    .abl-toggle-knob {
        width: 20px;
        height: 20px;
        background: linear-gradient(to bottom, #ffffff 0%, #cfe9f5 45%, #9fd0e8 55%, #ffffff 100%);
        border: 1px solid rgba(255, 255, 255, 0.9);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
        border-radius: 0;
        position: absolute;
        top: 1px;
        left: 2px;
        transition: left 0.2s ease;
    }

    .abl-toggle.on .abl-toggle-knob {
        left: 22px;
    }

    .abl-cloud-key-input {
        border-radius: 0 !important;
    }

    #abl-export-keys,
    #abl-import-keys,
    .abl-add-key,
    .abl-remove-key {
        border-radius: 0 !important;
        background: linear-gradient(to bottom, rgba(255, 255, 255, 0.5) 0%, rgba(255, 255, 255, 0.1) 14%, rgba(255, 255, 255, 0) 50%), linear-gradient(to bottom, #3fc6ff 0%, #0d6fa8 55%, #073757 100%) !important;
        border: 1px solid rgba(210, 245, 255, 0.7) !important;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.85), 0 1px 3px rgba(0, 0, 0, 0.5);
        color: #f2fdff !important;
        text-shadow: 0 1px 1px rgba(0, 20, 30, 0.6);
    }

    #abl-export-keys:hover,
    #abl-import-keys:hover,
    .abl-add-key:hover,
    .abl-remove-key:hover {
        filter: brightness(1.12);
    }

    .abl-theme-btn {
        padding: 8px 14px;
        border-radius: 0 !important;
        background: linear-gradient(to bottom, rgba(255, 255, 255, 0.5) 0%, rgba(255, 255, 255, 0.1) 14%, rgba(255, 255, 255, 0) 50%), linear-gradient(to bottom, #3fc6ff 0%, #0d6fa8 55%, #073757 100%);
        border: 1px solid rgba(210, 245, 255, 0.4);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.4), 0 1px 3px rgba(0, 0, 0, 0.4);
        color: #cfe9f5;
        text-shadow: 0 1px 1px rgba(0, 20, 30, 0.5);
        cursor: pointer;
        opacity: 0.6;
        font-size: 13px;
        font-weight: 600;
    }

    .abl-theme-btn.active {
        opacity: 1;
        border: 1px solid rgba(235, 235, 235, 0.9);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.85), 0 0 8px rgba(120, 200, 255, 0.5);
    }

    .abl-theme-preview {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px;
        margin-top: 16px;
        color: var(--color-content-default, inherit);
        background-color: var(--abl-color-surface, rgb(11, 11, 14));
        background-image: var(--abl-gloss), var(--abl-wash);
        border: 1px solid var(--abl-panel-border, rgba(150, 215, 255, 0.3));
        border-top-color: var(--abl-panel-border-top, rgba(210, 245, 255, 0.85));
    }

    .abl-theme-preview-btn {
        padding: 6px 14px;
        border-radius: 0;
        background-color: var(--abl-btn-mid, hsl(200, 85.5%, 36%));
        background-image: linear-gradient(to bottom, var(--abl-btn-top, hsl(200, 95%, 62%)) 0%, var(--abl-btn-mid, hsl(200, 85.5%, 36%)) 55%, var(--abl-aero-accent-dark, hsl(204, 85.5%, 18%)) 100%);
        border: 1px solid var(--abl-aero-border-bright, rgba(210, 245, 255, 0.85));
        color: #fff;
        font-size: 12px;
        font-weight: 600;
        text-shadow: 0 1px 1px rgba(0, 20, 30, 0.6);
        cursor: default;
    }

    .abl-theme-preview-chip {
        width: 26px;
        height: 26px;
        border: 3px solid var(--p-rarity, #ffd700);
    }
    `;
        document.head.appendChild(style);
        const menu = document.querySelector("ul.menu-vertical[role='tablist']");
        const tabContent = document.querySelector(".tab-content.rbx-tab-content");
        const title = document.getElementById("react-user-account-base")?.querySelector("h1");
        const ABL_TABS = {
          "abl-general-settings": {
            href: "?abl=general-settings",
            render: () => renderAblTab("abl-general-settings")
          },
          "abl-cloud-keys": {
            href: "?abl=cloud-keys",
            render: () => renderAblTab("abl-cloud-keys")
          },
          "abl-theme": {
            href: "?abl=theme",
            render: () => renderAblTab("abl-theme")
          },
          "abl-back": {
            href: "https://www.roblox.com/my/account#!/info",
            back: true
          }
        };
        menu.addEventListener("click", async (e) => {
          const a = e.target.closest("a");
          if (!a) return;
          const li = a.closest("li");
          const tab = ABL_TABS[li?.id];
          if (!tab) return;
          e.preventDefault();
          if (tab.back) {
            location.href = tab.href;
            return;
          }
          if (location.search === tab.href) return;
          history.pushState(null, "", tab.href);
          setActive(li);
          tab.render();
        });
        function getSetting(key) {
          return new Promise((resolve) => {
            chrome.storage.local.get(key, (res) => {
              resolve(res[key]);
            });
          });
        }
        function setSetting(key, value) {
          return new Promise((resolve) => {
            chrome.storage.local.set({ [key]: value }, resolve);
          });
        }
        function hexToHueSat(hex) {
          const r = parseInt(hex.slice(1, 3), 16) / 255;
          const g = parseInt(hex.slice(3, 5), 16) / 255;
          const b = parseInt(hex.slice(5, 7), 16) / 255;
          const max = Math.max(r, g, b);
          const min = Math.min(r, g, b);
          const l = (max + min) / 2;
          let h = 0;
          let s = 0;
          if (max !== min) {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
              case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
              case g:
                h = (b - r) / d + 2;
                break;
              case b:
                h = (r - g) / d + 4;
                break;
            }
            h *= 60;
          }
          return { hue: Math.round(h), sat: Math.round(s * 100) };
        }
        function hslToHex(h, s, l) {
          s /= 100;
          l /= 100;
          const k = (n) => (n + h / 30) % 12;
          const a = s * Math.min(l, 1 - l);
          const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
          const toHex = (x) => Math.round(255 * x).toString(16).padStart(2, "0");
          return `#${toHex(f(0))}${toHex(f(8))}${toHex(f(4))}`;
        }
        function makeOption(id, text, href) {
          const li = document.createElement("li");
          li.id = id;
          li.className = "menu-option";
          li.setAttribute("role", "tab");
          li.append(
            /* @__PURE__ */ createElement("a", { className: "menu-option-content", href }, /* @__PURE__ */ createElement("span", { className: "font-caption-header" }, text), /* @__PURE__ */ createElement("span", { className: "rbx-tab-subtitle" }))
          );
          return li;
        }
        function saveCloudKeys() {
          const keys = [...document.querySelectorAll(".abl-cloud-key-input")].map((i) => i.value);
          chrome.storage.local.set({ ablCloudKeys: keys });
        }
        async function getBool(key, fallback = false) {
          const val = await getSetting(key);
          return val ?? fallback;
        }
        function syncCloudKeyButtons(container) {
          const rows = container.querySelectorAll(".abl-row");
          rows.forEach((r, i) => {
            const add = r.querySelector(".abl-add-key");
            const remove = r.querySelector(".abl-remove-key");
            if (add) {
              add.hidden = i !== rows.length - 1;
              add.disabled = i !== rows.length - 1;
            }
            if (remove) {
              remove.hidden = i === 0;
              remove.disabled = i === 0;
            }
          });
        }
        function addCloudKeyRow(container, value = "") {
          const row = document.createElement("div");
          row.className = "abl-row";
          row.style.display = "flex";
          row.style.marginBottom = "8px";
          row.style.alignItems = "center";
          row.append(
            /* @__PURE__ */ createElement("input", { className: "form-control input-field abl-cloud-key-input", placeholder: "Cloud Key", value, style: { flex: "1" } }),
            /* @__PURE__ */ createElement("div", { style: { width: "90px", display: "flex", justifyContent: "flex-end", gap: "6px" } }, /* @__PURE__ */ createElement("button", { className: "btn-control-xs abl-remove-key", type: "button", style: { fontSize: "20px", width: "40px", height: "40px" } }, "\u2212"), /* @__PURE__ */ createElement("button", { className: "btn-control-xs abl-add-key", type: "button", style: { fontSize: "20px", width: "40px", height: "40px" } }, "+"))
          );
          const addBtn = row.querySelector(".abl-add-key");
          const removeBtn = row.querySelector(".abl-remove-key");
          removeBtn.addEventListener("click", () => {
            const firstRow = container.querySelector(".abl-row");
            if (row === firstRow) return;
            row.remove();
            saveCloudKeys();
            syncCloudKeyButtons(container);
          });
          addBtn.addEventListener("click", () => {
            addCloudKeyRow(container, "");
            saveCloudKeys();
            syncCloudKeyButtons(container);
          });
          let timeout;
          row.querySelector("input").addEventListener("input", () => {
            clearTimeout(timeout);
            timeout = setTimeout(saveCloudKeys, 200);
          });
          container.appendChild(row);
          syncCloudKeyButtons(container);
        }
        async function addSettingButton(tabContent2, key, text) {
          const enabled = await getBool(key, true);
          const row = document.createElement("div");
          row.style.display = "flex";
          row.style.alignItems = "center";
          row.style.justifyContent = "space-between";
          row.style.marginBottom = "12px";
          row.append(
            /* @__PURE__ */ createElement("span", { className: "font-caption-header", style: { fontSize: "16px" } }, text),
            /* @__PURE__ */ createElement("div", { className: `abl-toggle ${enabled ? "on" : ""}` }, /* @__PURE__ */ createElement("div", { className: "abl-toggle-knob" }))
          );
          const toggle = row.querySelector(".abl-toggle");
          toggle.addEventListener("click", async () => {
            const isOn = toggle.classList.toggle("on");
            await setSetting(key, isOn);
          });
          tabContent2.appendChild(row);
        }
        function bindCloudKeysAction(list) {
          const exportBtn = document.getElementById("abl-export-keys");
          const importBtn = document.getElementById("abl-import-keys");
          const fileInput = document.getElementById("abl-import-file");
          exportBtn.addEventListener("click", () => {
            const keys = [...document.querySelectorAll(".abl-cloud-key-input")].map((i) => i.value.trim()).filter(Boolean);
            const blob = new Blob(
              [JSON.stringify({ ablCloudKeys: keys }, null, 2)],
              { type: "application/json" }
            );
            const url = URL.createObjectURL(blob);
            const anchor = document.createElement("a");
            anchor.href = url;
            anchor.download = "abl-cloud-keys.json";
            anchor.click();
            URL.revokeObjectURL(url);
          });
          importBtn.addEventListener("click", () => {
            fileInput.click();
          });
          fileInput.addEventListener("change", async () => {
            const file = fileInput.files[0];
            if (!file) return;
            try {
              const data = JSON.parse(await file.text());
              const keys = Array.isArray(data) ? data : data.ablCloudKeys;
              if (!Array.isArray(keys)) {
                alert("Invalid import file.");
                return;
              }
              const cleanedKeys = keys.map((key) => String(key).trim()).filter(Boolean);
              await setSetting("ablCloudKeys", cleanedKeys.length ? cleanedKeys : [""]);
              list.innerHTML = "";
              (cleanedKeys.length ? cleanedKeys : [""]).forEach((key) => {
                addCloudKeyRow(list, key);
              });
              syncCloudKeyButtons(list);
            } catch {
              alert("Invalid import file.");
            } finally {
              fileInput.value = "";
            }
          });
        }
        async function renderAblTab(id) {
          if (id === "abl-cloud-keys") {
            tabContent.replaceChildren(
              /* @__PURE__ */ createElement("div", { className: "section" }, /* @__PURE__ */ createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" } }, /* @__PURE__ */ createElement("h3", { style: { margin: "0" } }, "Cloud Keys"), /* @__PURE__ */ createElement("div", { id: "abl-cloud-key-actions", style: { display: "flex", gap: "8px" } }, /* @__PURE__ */ createElement("button", { className: "btn-control-sm", type: "button", id: "abl-export-keys" }, "Export"), /* @__PURE__ */ createElement("button", { className: "btn-control-sm", type: "button", id: "abl-import-keys" }, "Import"))), /* @__PURE__ */ createElement("input", { type: "file", id: "abl-import-file", accept: "application/json", hidden: true }), /* @__PURE__ */ createElement("div", { id: "abl-cloud-key-list" }))
            );
            const list = document.getElementById("abl-cloud-key-list");
            const keys = await getSetting("ablCloudKeys") ?? [""];
            keys.forEach((k) => addCloudKeyRow(list, k));
            bindCloudKeysAction(list);
            const cloudkeySettingsTab = /* @__PURE__ */ createElement("div", null);
            addSettingButton(cloudkeySettingsTab, "ablShutUpKeyWarning", "Remove Cloud Key Warning");
            const cloudKeyInstructions = /* @__PURE__ */ createElement("div", null, /* @__PURE__ */ createElement("h2", null, "How to get a cloud key?"), /* @__PURE__ */ createElement("div", null, /* @__PURE__ */ createElement("p", null, "1. Head to ", /* @__PURE__ */ createElement("a", { href: "https://create.roblox.com/dashboard/credentials", style: { color: "revert", textDecoration: "revert" } }, "Roblox API Keys")), /* @__PURE__ */ createElement("p", null, '2. Click on "Create API Key"'), /* @__PURE__ */ createElement("p", null, "3. Give it any name and description."), /* @__PURE__ */ createElement("p", null, '4. Select "inventory" under the "Select API System" textbox.'), /* @__PURE__ */ createElement("p", null, '5. Select "read" under the "Select Operations to Add" textbox.'), /* @__PURE__ */ createElement("p", null, "6. Generate the key, make sure to save it somewhere safe."), /* @__PURE__ */ createElement("p", null, "7. Paste the key into one of the text boxes here.")), /* @__PURE__ */ createElement("br", null));
            tabContent.appendChild(cloudKeyInstructions);
            tabContent.appendChild(cloudkeySettingsTab);
          }
          if (id === "abl-theme") {
            let siteTheme = function() {
              const rbxBody = document.querySelector("#rbx-body");
              if (!rbxBody) return "dark";
              if (rbxBody.classList.contains("light-theme")) return "light";
              if (rbxBody.classList.contains("dark-theme")) return "dark";
              return "dark";
            }, updatePreview = function(theme) {
              const vars = themeVars(theme, siteTheme());
              for (const name in vars) {
                preview.style.setProperty(name, vars[name]);
              }
              previewChip.style.setProperty("--p-rarity", vars["--abl-rarity-valuable"] || "#ffd700");
            }, setActivePresetButton = function(preset) {
              presetButtons.forEach((b) => b.classList.toggle("active", b.dataset.preset === preset));
              customRow.style.display = preset === "custom" ? "flex" : "none";
            };
            tabContent.replaceChildren(
              /* @__PURE__ */ createElement("div", { className: "section" }, /* @__PURE__ */ createElement("h3", null, "Theme"), /* @__PURE__ */ createElement("p", { className: "font-caption-body", style: { opacity: "0.7", marginBottom: "12px" } }, "Changes apply next time you load a game page."), /* @__PURE__ */ createElement("div", { id: "abl-theme-presets", style: { display: "flex", gap: "8px" } }, /* @__PURE__ */ createElement("button", { className: "abl-theme-btn", type: "button", "data-preset": "aero" }, "Aero"), /* @__PURE__ */ createElement("button", { className: "abl-theme-btn", type: "button", "data-preset": "mono" }, "Monochrome"), /* @__PURE__ */ createElement("button", { className: "abl-theme-btn", type: "button", "data-preset": "custom" }, "Custom")), /* @__PURE__ */ createElement("div", { id: "abl-theme-custom-row", style: { display: "none", alignItems: "center", gap: "10px", marginTop: "12px" } }, /* @__PURE__ */ createElement("span", { className: "font-caption-header", style: { fontSize: "14px" } }, "Accent color"), /* @__PURE__ */ createElement("input", { type: "color", id: "abl-theme-color", value: "#3fc6ff", style: { width: "44px", height: "32px", padding: "0", border: "none", background: "none", cursor: "pointer" } })), /* @__PURE__ */ createElement("div", { className: "abl-theme-preview", id: "abl-theme-preview" }, /* @__PURE__ */ createElement("button", { className: "abl-theme-preview-btn", type: "button" }, "Load"), /* @__PURE__ */ createElement("div", { className: "abl-theme-preview-chip", id: "abl-theme-preview-chip" }), /* @__PURE__ */ createElement("span", { style: { fontSize: "12px", opacity: "0.6" } }, "Preview")))
            );
            const presetButtons = [...document.querySelectorAll(".abl-theme-btn")];
            const customRow = document.getElementById("abl-theme-custom-row");
            const colorInput = document.getElementById("abl-theme-color");
            const preview = document.getElementById("abl-theme-preview");
            const previewChip = document.getElementById("abl-theme-preview-chip");
            const savedTheme = normalizeTheme(await getSetting("ablTheme"));
            setActivePresetButton(savedTheme.preset);
            updatePreview(savedTheme);
            if (savedTheme.preset === "custom") {
              colorInput.value = hslToHex(savedTheme.hue, savedTheme.sat, 55);
            }
            presetButtons.forEach((btn) => {
              btn.addEventListener("click", async () => {
                const preset = btn.dataset.preset;
                setActivePresetButton(preset);
                const theme = preset === "custom" ? { preset: "custom", ...hexToHueSat(colorInput.value) } : { preset, ...PRESETS[preset] };
                updatePreview(theme);
                await setSetting("ablTheme", theme);
              });
            });
            colorInput.addEventListener("input", async () => {
              const theme = { preset: "custom", ...hexToHueSat(colorInput.value) };
              updatePreview(theme);
              await setSetting("ablTheme", theme);
            });
          }
          if (id === "abl-general-settings") {
            tabContent.replaceChildren(
              /* @__PURE__ */ createElement("div", { className: "section" }, /* @__PURE__ */ createElement("h3", null, "General Settings"), /* @__PURE__ */ createElement("div", { id: "abl-general-settings-list" }))
            );
            const list = document.getElementById("abl-general-settings-list");
            addSettingButton(list, "ablEnabled", "Badge List Enabled");
            addSettingButton(list, "americanDates", "Switch to MM/DD/YYYY format");
          }
        }
        function showAblMenu() {
          if (!menu || !tabContent) return;
          menu.innerHTML = "";
          tabContent.innerHTML = "";
          const generalSettings = makeOption("abl-general-settings", "General Settings", ABL_TABS["abl-general-settings"].href);
          const cloudKeys = makeOption("abl-cloud-keys", "Cloud Keys", ABL_TABS["abl-cloud-keys"].href);
          const theme = makeOption("abl-theme", "Theme", ABL_TABS["abl-theme"].href);
          const returnBtn = makeOption("abl-back", "Return", ABL_TABS["abl-back"].href);
          menu.append(generalSettings, cloudKeys, theme, returnBtn);
          const key = new URLSearchParams(location.search).get("abl") || "general-settings";
          const tab = menu.querySelector(`#abl-${key}`) || generalSettings;
          setActive(tab);
          renderAblTab(tab.id);
        }
        function setActive(tab, activeClass = "active") {
          document.querySelectorAll(".menu-option-content").forEach((a) => {
            a.classList.remove("active");
          });
          tab.querySelector("a").classList.add(activeClass);
        }
        function inject() {
          const params2 = new URLSearchParams(window.location.search);
          if (params2.get("abl") || !menu || document.getElementById("abl-settings")) return false;
          const settings = makeOption(
            "abl-settings",
            "ABL Settings",
            "?abl=general-settings"
          );
          settings.querySelector("a").addEventListener("click", (e) => {
            e.preventDefault();
            title.textContent = "Aero Badge List Settings";
            history.pushState(null, "", "?abl=general-settings");
            showAblMenu();
          });
          menu.appendChild(settings);
          return true;
        }
        inject();
        const params = new URLSearchParams(window.location.search);
        if (params.get("abl")) {
          title.textContent = "Aero Badge List Settings";
          showAblMenu();
        }
      })();
    }
  });
  require_settings();
})();
